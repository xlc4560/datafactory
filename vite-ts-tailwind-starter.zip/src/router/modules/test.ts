import Index from '@/pages/Index.vue';
export default {
  path: '/',
  component: Index,
  meta: {
    title: 'Vite + Vue + TypeScript + Tailwind Starter Template',
  },
};
