module.exports = {
  printWidth: 200,
  semi: true,
  vueIndentScriptAndStyle: true,
  singleQuote: true,
  trailingComma: 'all',
  proseWrap: 'never',
  htmlWhitespaceSensitivity: 'strict',
  endOfLine: 'auto',
  bracketSpacing: true,
  arrowParens: 'avoid',
};
